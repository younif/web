#define PROJECT_BINARY_DIR "/mnt/c/Users/youni/CLionProjects/web/cmake-build-debug"
#define PROJECT_SOURCE_DIR "/mnt/c/Users/youni/CLionProjects/web"
